Group number - 17

members - 
	1. Prateek Chandan	- 120050042
	2. Aditya Kumar Akash	- 120050046
	3. Naveen Sagar		- 120050026

All work that we are submitting for this assignment is our own work and we have not plagiarized it from anywhere.
INSTRUCTIONS --
The Folder Structur of SVN repository is :
project => trunk
		=> branches =>
					-g1701
					-g1702
					-g1703
Branches in GIT repo are Master , g1701 , g1702 ,g1703

g1701 is for Prateek Chandan
g1702 is for Aditya Kumar Akash
g1703 is for Naveen Sagar

# For Execution of Code
Make setup- for installing Box2D
Make exe - for compiling codes and making executable

executable is created in mybins/cs296_17_exe

CITATIONS-- 

We referred to the the SVN and GIT Manual and Svn-Git Crach Course sites provided to us on the lab assignemnt webpage
