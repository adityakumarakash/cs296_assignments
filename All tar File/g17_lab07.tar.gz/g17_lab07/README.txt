READ ME for Lab7---

Group number - 17

members - 
	1. Aditya Kumar Akash	- 120050046
	2. Prateek Chandan	- 120050042
	3. Naveen Sagar		- 120050026

All work that we are submitting for this assignment is our own work and we have not plagiarized it from anywhere.

CITATIONS-- 

We referred to the online documentation of awk , sed and advanced bash scripting guide

Other Sources which we made use for our study include -- 
	1.GNU Manual
	2.Manuals for gprof and perf
	3.stackoverflow
	4.google.com

