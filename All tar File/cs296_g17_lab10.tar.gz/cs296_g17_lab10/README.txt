READ ME for Lab9---

Group number - 17

members - 
	1. Aditya Kumar Akash	- 120050046
	2. Prateek Chandan	- 120050042
	3. Naveen Sagar		- 120050026


NOTE :- 
please provide the path to the script "wrt to the javaclasses folder" which will be created

CITATIONS-- 

We referred to the online documentation of java and javadoc

the OOP principles used are the 
1.Inheritance
The 'Movie' class inherits from the ReadTextFile class because this class has the inherent same 
property of reading the text file which is script here in this case and hence
it makes sense to inherit

2.Polymorphism
There are many functions as
isPresent
isCommon

which have same function names but different parameter list 
These functions behave differently in different situation and hence it has polymorphism


Other Sources which we made use for our study include -- 
	1.java oracle Manual
	2.stackoverflow
	3.google.com

Note : Run make report directly on the terminal to which will do everything

