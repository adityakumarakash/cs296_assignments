READ ME ---

Group number - 17

members - 
	1. Aditya Kumar Akash	- 120050046
	2. Prateek Chandan	- 120050042
	3. Naveen Sagar		- 120050026

All work that we are submitting for this assignment is our own work and we have not plagiarized it from anywhere.

CITATIONS-- 

We referred to the Makefile which was given in the cs296_base_code (We learnt about the temp.log and temp.err from the Supplied Makefile). We have followed the same pattern for naming the variable as in the Supplied Makefile.

Other Sources which we made use for our study include -- 
	1.http://tldp.org/HOWTO/Program-Library-HOWTO/shared-libraries.html
	2.stackoverflow
	3.http://www.yolinux.com/TUTORIALS/LibraryArchives-StaticAndDynamic.html
	4.http://linuxcommand.org/learning_the_shell.php#contents
	5.https://www.gnu.org/software/make/manual/html_node/index.html#Top
	6.google.com

*note- the 'make' only installs the box2d, to create executable use 'make exe' or 'make exelib'
