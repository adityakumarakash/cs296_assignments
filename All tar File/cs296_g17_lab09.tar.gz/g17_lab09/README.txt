READ ME for Lab9---

Group number - 17

members - 
	1. Aditya Kumar Akash	- 120050046
	2. Prateek Chandan	- 120050042
	3. Naveen Sagar		- 120050026



CITATIONS-- 

We referred to the online documentation of python , matplotlib and other resources

Other Sources which we made use for our study include -- 
	1.Python Manual
	2.Matplot Manual
	3.stackoverflow
	4.google.com

Note : Run make report directly on the terminal to which will do everything

